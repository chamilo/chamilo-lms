<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langPgTitle = "Intestazione della pagina";
$langExplanation = "La pagina deve essere in formato HTML (ad es. \"my_page.htm\"). Sar� accessibile dalla Pagina principale del corso. Se desiderate inviare documenti in formato diverso (PDF, Word, Power Point, Video, ecc.) utilizzate lo strumento <a href=../document/document.php>Documenti</a>";
$langTooBig = "Non � stato selezionato nessun documento oppure la dimensione � eccessiva";
$langCouldNot = "Non � stato possibile inviare il documento";
$langNotAllowed = "Non consentito";
$langAddPageToSite = "Aggiungi una pagina al sito";
$langCouldNotSendPage = "Il documento non � in formato HTML e non � stato possibile inviarlo. Se desiderate inviare documenti in formato diverso (PDF, Word, Power Point, Video, ecc.) utilizzate lo strumento <a href=../document/document.php>Documenti</a>";
$langSendPage = "Pagina da inviare";
$langPageTitleModified = "L\'intestazione della pagina � stata modificata";
$langPageAdded = "Pagina aggiunta";
$langAddPage = "Aggiungi una pagina";
$Choose = "Scegli il file";
?>