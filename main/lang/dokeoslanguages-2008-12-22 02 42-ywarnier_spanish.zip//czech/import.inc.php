<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langPgTitle = "N�zev str�nky";
$langExplanation = "Str�nka mus� b�t ve form�tu HTML (nap&#345;. \"moje_stranka.htm\"). Bude spojen� s Dom�c� str�nkou. Jestli chcete poslat dokumenty kter� nejsou ve form�tu HTML(PDF, Word, Power Point, Video, atd.) pou�ijte <a href=../document/document.php>N�stroj dokument&#367;</a>";
$langTooBig = "Nevybrali jste ��dn� soubor pro nahr�n�, nebo je soubor p&#345;�li� velik�.";
$langCouldNot = "Soubor nem&#367;�e b�t nahr�n.";
$langNotAllowed = "Nedovoleno";
$langAddPageToSite = "P&#345;idat str�nku na m�sto";
$langCouldNotSendPage = "Tento soubor nen� ve form�tu HTML a nem&#367;�e b�t nahr�n. Jestli chcete poslat dokumenty kter� nejsou ve form�tu HTML (PDF, Word, Power Point, Video, atd.) pou�ijte <a href=../document/document.php>N�stroj dokument&#367;</a>";
$langSendPage = "Str�nka pro nahr�n�(upload)";
$langPageTitleModified = "N�zev str�nky byl zm&#283;n&#283;n";
$langPageAdded = "Str�nka p&#345;idan�";
$langAddPage = "P&#345;idat str�nku";
?>