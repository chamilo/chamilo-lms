<?php /*
for more information: see languages.txt in the lang folder. 
*/
$nameTools = "variabili non utilizzate";
$langMdCallingTool = "Moduli Scorm";
$langTool = "Operazioni metadata Scorm";
$langNotInDB = "non ci sono informazioni nel Database";
$langManifestSyntax = "(errore di sintassi nel manifest...)";
$langEmptyManifest = "(manifest vuoto...)";
$langNoManifest = "(non c\'� il manifest...)";
$langNotFolder = "non sono possibili, non si tratta di una cartella...";
$langUploadHtt = "Carica un file HTT";
$langHttFileNotFound = "Il nuovo file HTT non pu� essere aperto (vuoto? troppo pesante?...) ";
$langHttOk = "Il nuovo file HTT � stato caricato";
$langHttNotOk = "Il caricamento del file HTT � fallito";
$langRemoveHtt = "Elimina il file HTT";
$langHttRmvOk = "Il file HTT � stato eliminato";
$langHttRmvNotOk = "Non � stato possibile eliminare il file HTT";
$langImport = "Crea MDE dal manifest";
$langRemove = "Elimina gli MDE";
$langAllRemovedFor = "Tutte le voci sono state eliminate";
$langIndex = "Indicizza le parole con PhpDig";
$langTotalMDEs = "Numero totale di voci metadata dello Scorm";
$langMainMD = "Apri MDE principale";
$langLines = "linee";
$langPlay = "Esegui index.php";
$langNonePossible = "Non ci sono operazioni MD possibili";
$langOrElse = "Seleziona una cartella Scorm o un suo identificatore";
$langWorkWith = "Lavora con le cartelle Scorm";
$langSDI = "...Cartella Scorm con SD-id (dividi il manifest o lascialo vuoto)";
$langRoot = "root";
$langSplitData = "Dividi il manifest e il #MDe, se ce ne sono";
$langMffNotOk = "Non � stato possibile sostituire il file manifest";
$langMffOk = "Il file manifest � stato sostituito";
$langMffFileNotFound = "Il nuovo manifest non pu� essere aperto (vuoto? molto grande)...";
$langUploadMff = "Sostituisci il file manifest";
?>