<?php /*
for more information: see languages.txt in the lang folder. 
*/
$lang_september = "九月";
$langClassName = "班级名称";
$lang_agenda = "日程";
$langDay = "日";
$langYear = "年";
$langHour = "时";
$langMinute = "分";
$langLasting = "持续时间";
$langOldToNew = "旧到新";
$langNewToOld = "新到旧";
$langNow = "现在";
$langAddEvent = "添加事件";
$langDetail = "详细内容";
?>