<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langScormBuilder = "Yol yap&#305;c&#305; - Scorm bi�em ders yap&#305;c&#305; ";
?>