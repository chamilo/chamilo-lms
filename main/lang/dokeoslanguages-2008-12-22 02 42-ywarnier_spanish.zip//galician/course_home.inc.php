<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langActivate = "Activar";
$langDeactivate = "Desactivar";
$langInLnk  = "Ligaz�ns desactivadas";
$langDelLk = "�Est�s seguro de que queres desactivar esta ligaz�n?";
$langEnter  = "Entrar";
$langCourseCreate  = "Crear un Curso";
$langNameOfTheLink  = "Nome da ligaz�n";
$lang_main_categories_list                  = "Lista de categor�as principais";
$langCourseAdminOnly = "S� profesores";
$PlatformAdminOnly = "S� administradores da plataforma";
$langCombinedCourse = "Curso combinado";
$ToolIsNowVisible = "A ferramenta � agora visible";
$ToolIsNowHidden = "A ferramenta � agora invisible";
$EditLink = "Editar ligaz�n";
$Blog_management = "Xesti�n do blog";
$Forum = "Foros";
$Course_maintenance = "Mantemento do curso";
$TOOL_SURVEY = "Enquisas";
$GreyIcons = "Ferramentas";
$Interaction = "Interacci�n";
$Authoring = "Creaci�n de contidos";
$Administration = "Administraci�n";
$IntroductionTextUpdated = "Actualizouse a mensaxe introdutoria";
$IntroductionTextDeleted = "Texto de introduci�n eliminado.";
?>