<?php /*
for more information: see languages.txt in the lang folder. 
*/
$select = "Seleccionar";
$square = "Quadrat";
$circle = "El�lipse";
$poly = "Pol�gon";
$status1 = "Dibuixar una zona interactiva";
$status2_poly = "Utilitzeu el bot� dret del ratol� per tancar el pol�gon";
$status2_other = "Deixeu anar el bot� del ratol� per guardar la zona interactiva";
$status3 = "Zona interactiva guardada";
$exercise_status_1 = "Estatus: Pregunta sense contestar";
$exercise_status_2 = "Validar les respostes";
$exercise_status_3 = "Estatus: Pregunta contestada";
$showUserPoints = "Mostrar/Ocultar clics";
$showHotspots = "Mostrar/Ocultar zones interactives";
$labelPolyMenu = "Tancar pol�gon";
$triesleft = "Intents restants";
$exeFinished = "Totes les zones han estat seleccionades. Ara podeu modificar les vostres respostes o clicar per validar.";
$nextAnswer = "Ara cliqueu a: &done=done";
?>