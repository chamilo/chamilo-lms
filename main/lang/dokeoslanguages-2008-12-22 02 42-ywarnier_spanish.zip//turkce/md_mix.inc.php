<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langTool = "Metadata";
$langClickKw = "Se�mek veya iptal etmek i�in dallardaki bir kelimenin �zerine t&#305;klay&#305;n";
$langKwHelp = "<br/> Click \'+\' button to open, \'-\' button to close, \'++\' button to open all, \'--\' button to close all.<br/> <br/> Clear all selected keywords by closing the tree and opening it again with the \'+\' button.<br/> Alt-click \'+\' re-selects the previously selected keywords.<br/> <br/> Alt-click keyword negates the keyword.<br/>";
$langAdvanced = "Geli&#351;mi&#351;";
$langSearch = "Ara&#351;t&#305;rma";
$langSearchCrit = "a�&#305;klay&#305;c&#305; kelimeler i�in a&#351;a&#287;&#305;daki alan&#305; kullan&#305;n, her sat&#305;ra bir kelime !";
$langNoKeywords = "Bu ders i�in anahtar kelime yok";
$langKwCacheProblem = "Anahtar kelime �n belle&#287;i a�&#305;lam&#305;yor.";
$langCourseKwds = "ders anahtar kelimeleri";
$langKwdsInMD = "MD i�inde kullan&#305;lan anahtar kelimeler";
$langKwdRefs = "anahtar kelime referanslar&#305;";
$langNonCourseKwds = "Derse ait olmayan anahtar kelimeler";
$langKwdsUse = "Ders anahtar kelimeleri (koyu = kullan&#305;lm&#305;yor)";
$langTotalMDEs = "MD giri&#351;lerinin toplam say&#305;s&#305;:";
?>