<?php /*
for more information: see languages.txt in the lang folder. 
*/
$nameTools = "kullan&#305;lmayan lisan de&#287;i&#351;keni";
$langMdCallingTool = "KURS - SCORM";
$langTool = "Scorm MD i&#351;lemleri";
$langNotInDB = "DB giri&#351;i yok";
$langManifestSyntax = "(a�&#305;klama dosyas&#305;nda yaz&#305;m hatas&#305;...)";
$langEmptyManifest = "(bo&#351; a�&#305;klama dosyas&#305;...)";
$langNoManifest = "(a�&#305;klama dosyas&#305; yok...)";
$langNotFolder = "m�mk�n de&#287;il, o bir klas�r de&#287;il...";
$langUploadHtt = "HTT dosyas&#305; g�nder";
$langHttFileNotFound = "Yeni HTT dosyas&#305; a�&#305;lamad&#305; (bo&#351;, �ok b�y�k vs)";
$langHttOk = "Yeni HTT dosyas&#305; sisteme g�nderildi.";
$langHttNotOk = "HTT dosya transferi ba&#351;ar&#305;s&#305;z";
$langRemoveHtt = "HTT dosyas&#305; sil";
$langHttRmvOk = "HTT dosyas&#305; silindi";
$langHttRmvNotOk = "HTT dosya silme i&#351;lemi ba&#351;ar&#305;s&#305;z oldu";
$langImport = "Listeden MDE olu&#351;tur";
$langRemove = "MDE sil";
$langAllRemovedFor = "All entries removed for";
$langIndex = "Index Words with PhpDig";
$langTotalMDEs = "Scorm MD giri&#351;leri toplam say&#305;s&#305;:";
$langMainMD = "Ana MDE a�";
$langLines = "sat&#305;r";
$langPlay = "index.php yi oynat";
$langNonePossible = "MD i&#351;lemleri m�mk�n de&#287;il";
$langOrElse = "Bir Scorm Direkt�r� veya ID si se�";
$langWorkWith = "Scorm Direkt�r� ile �al&#305;&#351;";
$langSDI = "... Scorm Directory with SD-id (and split manifest - or leave empty)";
$langRoot = "ana dizin";
$langSplitData = "Split manifests, and #MDe, if any: ";
$langMffNotOk = "Liste dosyas&#305;n&#305; tekrar yerine koyma  i&#351;lemi ba&#351;ar&#305;s&#305;z oldu";
$langMffOk = "Liste dosyas&#305; tekrar yerine konuldu";
$langMffFileNotFound = "Yeni liste dosyas&#305; a�&#305;lam&#305;yor (bo&#351;, �ok b�y�k vs)";
$langUploadMff = "Liste dosyas&#305;n&#305; tekrar yerine koy";
?>