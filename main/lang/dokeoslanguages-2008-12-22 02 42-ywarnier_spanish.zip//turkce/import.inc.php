<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langPgTitle = "Sayfan�n ba�l���";
$langExplanation = "Sayfa HTML format�nda olmal�d�r (�rnek: \"felsefe_odevi.htm\"). E�er HTML olmayan bir dosya g�ndermek istiyorsan�z (PDF, Word, Power Point, Video, etc.) use <a href=../document/document.php>Belge Ara�lar�n� kullan�n�z</a>";
$langTooBig = "Bir dosya se�mediniz veya �ok b�y�k";
$langCouldNot = "Dosya g�nderilemedi";
$langNotAllowed = "�zin verilmiyor";
$langAddPageToSite = "Siteye sayfa ekle";
$langCouldNotSendPage = "Bu sayfa HTML format�nda de�il bu nedenle g�nderilemez. E�er HTML olmayan bir dosya g�ndermek istiyorsan�z (PDF, Word, Power Point, Video, etc.) <a href=../document/document.php>Belge Ara�lar�n� kullan�n�z</a>";
$langSendPage = "G�nderilecek sayfa";
$langPageTitleModified = "Sayfa ba�l��� de�i�tirildi";
$langPageAdded = "Sayfa eklendi";
$langAddPage = "Sayfa ekle";
?>