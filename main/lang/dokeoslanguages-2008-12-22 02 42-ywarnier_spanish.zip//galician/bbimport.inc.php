<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langViewCourseMaterialImport  = "Ver o material do curso tal e como ser� importado";
$langViewExternalLinksImport  = "Ver as ligaz�ns externas tal e como ser�n importadas";
$langViewForumImport  = "Ver o foro tal e como ser� importado";
$langImportCourseMaterial  = "Importar material do curso (M�dulo de Blackboard \"Material do curso\")";
$langImportExternalLinks  = "Importar ligaz�ns (M�dulo Blackboard \"Ligaz�ns externas\")";
$langImportForum  = "Importar foros (M�dulo Blackboard \"Foros\")";
$langToolInfo  = "Esta ferramenta importa cursos de Blackboard 5.5 (Material do curso, foros, e ligaz� externas). <br> En un futuro importa� m�is m�dulos, Blackboard 6 e cursos WebCT, e paquetes IMS e SCORM.";
$langToolName = "Importar cursos de Blackboard";
$langSelectCoursePackage = "Seleccionar un paquete de curso";
$langPackageAlreadySelected = "Xa seleccionou un paquete";
$langFirstSelectPackage = "Primeiro ten que seleccionar un paquete e abrilo antes de poder importalo. ";
$langCourseToMigrate = "Curso para migrar";
$langSelectPackage = "Seleccionar un paquete";
$langOpenPackageForImporting = "Abrir este paquete para importar";
$langInformation = "Informaci�n sobre o proceso de importaci�n";
$langChooseImportOptions = "Escolla as opci�ns de importaci�n";
$langCheckWhatIsImported = "Pode comprobar o que vai ser importado antes de comezar co proceso";
$langStartImporting = "Comezar a importar";
$langImport = "Importar";
?>