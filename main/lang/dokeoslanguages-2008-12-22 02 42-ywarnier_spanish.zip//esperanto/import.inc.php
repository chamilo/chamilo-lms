<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langPgTitle = "Pa&#285;a titolo ";
$langExplanation = "&#264;i-pa&#285;o estu en HTMLa formato (ekz. \"Mia_pagxo.html\"). &#284;i estos ligata al la hejmpa&#285;o de la kursa retejo. Por sendi ne-HTML-an dokumenton (PDF, Power Point, Word...) uzu <a href=../document/document.php>Dokumentojn</a>";
$langTooBig = "Vi ne elektis sendotan dosieron a&#365; via dosiero estas tro granda. ";
$langCouldNot = "Dosiero ne povis esti sendata ";
$langNotAllowed = "Vi ne estas kursmastrumanto. Vi ne povas fari tion. ";
$langAddPageToSite = "Aldoni pa&#285;on al la kursan retejon ";
$langCouldNotSendPage = "&#264;i-dosiero ne estas en HTML-formato kaj tial ne povis esti sendata. Se vi volas sendi al la servilo dokumentojn ne HTML-ajn (PDF, Word, Power Point, Video, ktp.) vi uzu <a href=../document/document.php>Dokumentojn</a>";
$langSendPage = "Sendi pa&#285;on ";
$langPageTitleModified = "Titola pa&#285;o estas &#349;an&#285;ita ";
$langPageAdded = "Pa&#285;o estas aldonita ";
$langAddPage = "Aldoni pa&#285;on ";
?>