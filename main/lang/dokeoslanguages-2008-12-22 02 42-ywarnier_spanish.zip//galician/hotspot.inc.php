<?php /*
for more information: see languages.txt in the lang folder. 
*/
$select = "Seleccionar";
$square = "Rect�ngulo";
$circle = "Elipse";
$poly = "Pol�gono";
$status1 = "Debuxar un hotspot.";
$status2_poly = "Use o bot�n dereito do rato para pechar o pol�gono.";
$status2_other = "Solte o bot�n do rato para gardar o hotspot.";
$status3 = "Hotspot gardado";
$exercise_status_1 = "Estatus: Pregunta a�nda sen terminar";
$exercise_status_2 = "Pulse aqu� para enviar as s�as respostas � pregunta";
$exercise_status_3 = "Estatus: Pregunta terminada";
$showUserPoints = "Mostrar/Ocultar os clics";
$showHotspots = "Mostrar/Ocultar hotspots";
$labelPolyMenu = " 	Pechar pol�gono";
$triesleft = "Intentos restantes";
$exeFinished = "Identific�ronse todas as respostas. Agora pode reasignar as s�as respostas ou pulsar para enviar.";
$nextAnswer = "Agora faga clic en: &done=done";
?>