<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langCourseProgram  = "Kurso: loki&#285;o kaj flanka informo ";
$langThisCourseDescriptionIsEmpty  = "&#264;i-kurso ne ankora&#365; havas priskribon ";
$langEditCourseProgram  = "Krei / adapti kursinformon ";
$QuestionPlan  = "Demando pri la planado <BR> por la instruisto ";
$langInfo2Say  = "Informo por komuniko al <BR> la studento ";
$langOuAutreTitre  = "Titolo ";
$langNewBloc  = "Aliaj (libere aldoneblaj) ";
$langAddCat  = "Aldoni kategoriojn ";
$langAdd  = "Aldoni";
$langValid  = "En ordo ";
$langBackAndForget  = "Nuligi ";
?>