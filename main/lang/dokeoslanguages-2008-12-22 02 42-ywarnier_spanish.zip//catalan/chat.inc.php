<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langOnlineConference  = "Confer�ncia en l�nia";
$langWash  = "Renta";
$langReset  = "Reiniciar";
$langSave  = "Guarda";
$langRefresh  = "Actualitza";
$langIsNowInYourDocDir  = "ara es troba a la vostra eina de document. <br><B>Aquest fitxer �s visible</B>";
$langCopyFailed  = "Error d\'impressi�";
$langTypeMessage  = "Escriviu el vostre missatge !";
$langConfirmReset  = "Esteu segur de voler esborrar tots els missatges ?";
$langHasResetChat  = "heu esborrat els missatges";
$langNoOnlineConference  = "No hi ha confer�ncies per ara ...";
$langMediaFile  = "Fitxer �udio o v�deo";
$langContentFile  = "Presentaci�";
$langListOfParticipants  = "Llista dels participants";
$langYourPicture  = "La vostra foto";
$langOnlineDescription  = "Descripci� de la confer�ncia";
$langOnlyCheckForImportantQuestion = "Marqueu la casella en el cas que vulgueu fer una pregunta important !";
$langQuestion = "pregunta";
$langClearList = "Esborrar la llista";
$langWhiteBoard = "Editor";
$langTextEditorDefault = "<h2>Editor de text</h2>Talleu i enganxeu aqu� un text provinent de MS Word&Reg; i editeu-lo. Els altres participants veuran les vostres modificacions en directe.";
$langStreaming = "Streaming";
$langStreamURL = "URL del stream";
$langStreamType = "Tipus del stream";
$langLinkName = "Nom de l\'enlla�";
$langLinkURL = "URL de l\'enlla�";
$langWelcomeToOnlineConf = "Benvingut a la <b>Confer�ncia en l�nia</b>";
$langNoLinkAvailable = "No hi ha enlla�os disponibles";
$langChat_reset_by = "Reiniciar el xat";
$OrFile = "O el fitxer";
$langCallSent = "S\'ha enviat una demanda de \"xat\". En espera de l\'aprovaci� de la persona contactada.";
$langChatDenied = "La vostra petici� ha estat refusada per la persona contactada.";
$Send = "Enviar";
$Connected = "Connectat";
?>