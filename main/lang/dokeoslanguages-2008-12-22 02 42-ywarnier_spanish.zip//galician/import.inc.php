<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langPgTitle = "T�tulo da p�xina";
$langExplanation = "Esta p�xina debe estar en formato HTML (por exemplo \"a_minha_paxina.html\"). Aparecer� a ligaz�n na p�xina principal do seu curso. Se vostede desexa enviar un documento que non est� en formato HTML (PDF, Power Point, Word...) utilice a funci�n <a href=../document/document.php>Documentos</a>";
$langTooBig = "Vostede non seleccionou ning�n arquivo para enviar, ou o arquivo � demasiado grande";
$langCouldNot = "O ficheiro non se puido enviar";
$langNotAllowed = "Vostede non est� identificado como responsable deste curso";
$langAddPageToSite = "A�adir unha p�xina � sitio";
$langCouldNotSendPage = "Este arquivo non ten formato HTML e polo tanto non se pode enviar. Se vostede desexa subir � servidor documentos que non est�n en formato HTML (PDF, Word, Power Point, V�deo, etc.) utilice<a href=../document/document.php>Documentos</a>";
$langSendPage = "Enviar P�xina";
$langPageTitleModified = "Modificouse o t�tulo da p�xina";
$langPageAdded = "Engad�use a p�xina";
$langAddPage = "Engadir unha p�xina";
?>