<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langToolName = "Statistika";
$TrackingDisabled = "Statistika byla deaktivov�na spr�vcem syst�mu.";
?>