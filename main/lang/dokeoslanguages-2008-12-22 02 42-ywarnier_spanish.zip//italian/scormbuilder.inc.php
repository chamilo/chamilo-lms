<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langScormBuilder = "Crea moduli didattici in formato Scorm";
?>