<?php /*
for more information: see languages.txt in the lang folder. 
*/
$lang_height = "Altezza";
$lang_resizing_comment = "ridimensiona l\'immagine con le seguenti dimensioni (in pixels)";
$lang_width = "Larghezza";
$lang_resizing = "Ridimensiona";
$lang_no_resizing_comment = "Mostra tutte le immagini nella loro dimensione originale. Se necessario, le barre di scorrimento appariranno automaticamente.";
$lang_show_thumbnails = "Mostra miniature";
$lang_click_thumbnails = "Clicca su una miniatura";
$lang_set_slideshow_options = "Imposta le opzioni della presentazione";
$lang_slideshow_options = "Opzioni della presentazione";
$lang_no_resizing = "Non ridimensionare (predefinita)";
$lang_exit_slideshow = "Esci dalla presentazione";
$SlideShow = "Presentazione";
$lang_previous_slide = "Diapositiva precedente";
$lang_next_slide = "Prossima Diapositiva";
$lang_image = "Immagine";
$lang_of = "di";
$lang_view_slideshow = "Mostra presentazione";
?>