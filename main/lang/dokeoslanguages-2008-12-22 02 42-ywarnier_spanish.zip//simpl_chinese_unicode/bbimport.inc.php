<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langViewCourseMaterialImport  = "查看要导入的课程材料";
$langViewExternalLinksImport  = "查看要导入的外部链接";
$langViewForumImport  = "查看要导入的论坛";
$langImportCourseMaterial  = "导入课程材料（毕博工具“课程材料”）";
$langImportExternalLinks  = "导入链接（毕博工具“外部链接”）";
$langImportForum  = "导入论坛（毕博工具“讨论板”）";
$langToolInfo  = "这个工具导入毕博 5.5 课程（课程材料，讨论板和外部链接）";
$langToolName = "导入毕博课程";
$langSelectCoursePackage = "选择课程包";
$langPackageAlreadySelected = "你已经选择了课程包";
$langFirstSelectPackage = "你必须首先选择一个包，然后在处理导入前打开它。";
$langCourseToMigrate = "迁移的课程";
$langSelectPackage = "选择包";
$langOpenPackageForImporting = "导入时打开这个包";
$langInformation = "导入处理的信息";
$langChooseImportOptions = "选择你的导入选项";
$langCheckWhatIsImported = "开始导入前，请查看要导入的内容";
$langStartImporting = "开始导入";
$langImport = "导入";
?>