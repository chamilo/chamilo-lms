<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langAnnEmpty = "通知列表已经被删除";
$langContent = "内容";
$langEmailSent = "发送邮件给学生";
$langOn = "在";
$langRegUser = "注册用户";
$langUnvalid = "无效或没有邮件地址";
$langModifAnn = "修改通知";
$langModify    = "修改";
$langDelete    = "删除";
$langTitle     = "标题";
$langHelp      = "帮助";
$langOk        = "确定";
$langAddIntro  = "添加介绍文本";
$langBackList  = "返回列表";
$langSelMess   = "对某些用户的警告";
$langUserlist  = "用户和小组列表";
$langSelectedUsers  = "选定的用户";
$langSubmit  = "提交";
$langPleaseEnterMessage  = "必须输入消息文本";
$langPleaseSelectUsers  = "必须选择用户";
$langMessages  = "消息";
$langMessageToSelectedUsers  = "发送给选定群组的消息";
$langIntroText  = "发送消息时，请选择用户组（在前面用G标识）或在左边列表框里单个用户。";
$langDown = "向下";
$langMsgSent = "消息已经发送给选定的用户";
$langSelUser = "选定的用户";
$langMessageToSelectedGroups = "发送给选定群组的消息";
$langGrouplist = "群组列表";
$langSelectedGroups = "选定的群组";
$langMsg = "消息";
$langYes = "确定";
?>