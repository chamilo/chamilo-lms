<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langLinkSite = "Enlla�a un lloc web";
$langSubTitle = "Afegir un enlla� extern o intern des de la p�gina principal del curs. Per fer-ho, ves a aquella plana, copia la seva adre�a que apareix a la barra \'URL\' de la part superior del teu navegador, i insereix-la en el camp \'enlla�\' de sota.";
$langAddPage            = "Afegir una p�gina";
$langSendPage           = "P�gina a enviar";
$langCouldNot           = "El fitxer no es pot enviar";
$langOkSentPage         = "La seva p�gina ha estat enviada.<p>Ara es troba enlla�ada des de la  <a href=\\\"../../\".$_course[\'path\'].\"/index.php\\\">p�gina principal del curs</a>";
$langOkSentLink         = "El seu enlla� ha estat enviat.<p>Aquest �s ara accessible des de la <a href=\\\"../../\".$_course[\'path\'].\"/index.php\\\">p�gina principal del curs</a>";
$langTooBig             = "No ha escollit cap arxiu a enviar, o �s massa gran";
$langExplanation        = "La p�gina ha d\'estar en format HTML (ex: \"my_page.htm\"). Ser� enlla�ada a la p�gina principal. Si voleu enviar un document NO HTML (PDF, Word, Power Point, Video, etc.) utilitzeu les <a href=../document/document.php>eines de documents</a>";
$langPgTitle            = "T�tol de la p�gina";
$langNoLinkURL          = "Introdueixi l\'adre�a de l\'enlla�";
$langLinkTarget = "Destinaci� de l\'enlla�";
$langSameWindow = "A la mateixa finestra";
$langNewWindow = "En una nova finestra";
$langAdded = "L\'enlla� ha estat afegit";
$langAddLink = "Afegir un enlla�";
$langNoLinkName = "Introdu�u el nom de l\'enlla�";
$langEditLink = "Editar l\'enlla� de la p�gina d\'inici del curs";
$langChangePress = "Feu els canvis i cliqueu OK";
$langLinkChanged = "L\'enlla� de la p�gina inicial del curs ha estat modificat. Utilitzeu el men� de navegaci� de la part superior per tornar a la p�gina inicial";
$NoLinkName = "L\'enlla� no t� nom";
$NoLinkURL = "L\'enlla� no t� URL";
$LinkChanged = "Enlla� modificat";
$OkSentLink = "L\'enlla� ha estat enviat";
?>