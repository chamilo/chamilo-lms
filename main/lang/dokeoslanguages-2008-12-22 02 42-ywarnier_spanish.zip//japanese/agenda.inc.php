<?php /*
for more information: see languages.txt in the lang folder. 
*/
$AgendaAdd = "Add new Agenda Item";
$ShowAll = "Show All Agenda Items";
$ShowCurrent = "Show Agenda Items of current month";
$AddCalendarItem = "Add a new Agenda item";
$Day = "Day";
$Month = "Month";
$Year = "Year";
$Hour = "Hour";
$Minutes = "Minutes";
$Detail = "Detail";
$EditSuccess = "The agenda item has been edited";
$AddSuccess = "Agenda item added";
$AgendaDeleteSuccess = "The agenda item has been deleted";
$NoAgendaItems = "There are no Agenda Items";
$lang_september = "September";
$langClassName = "&#12463;&#12521;&#12473;&#21517;";
?>