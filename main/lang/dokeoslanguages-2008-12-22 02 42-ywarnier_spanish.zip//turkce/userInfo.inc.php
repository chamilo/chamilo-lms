<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langLineNumber = "Sat&#305;r say&#305;s&#305;";
$langLine = "sat&#305;r";
$langLines = "sat&#305;rlar";
$langLineOrLines = "sat&#305;r(lar)";
$langMoveUp = "Yukar&#305; ta&#351;&#305;";
$langMoveDown = "A&#351;a&#287;&#305; ta&#351;&#305;";
$langAddNewHeading = "Yeni ba&#351;l&#305;k ekle";
$langCourseAdministratorOnly = "Sadece �&#287;retmenler";
$langDefineHeadings = "Ba&#351;l&#305;klar&#305; tan&#305;mla";
$langBackToUsersList = "Kullan&#305;c&#305; listesine d�n";
$langTracking = "&#304;zleme";
$langCourseManager = "�&#287;retmen";
$langModRight = "haklar&#305; de&#287;i&#351;tir";
$langNoAdmin = "bundan sonra bu sayfada haklar <b>yok</b>";
$langAllAdmin = "bundan sonra bu sayfadaki <b>t�m</b> haklar var";
$langModRole = "rol�n� de&#287;i&#351;tir";
$langRole = "stat�";
$langIsNow = "bundan sonra";
$langInC = "bu derste";
$langFilled = "B�t�n alanlar doldurulmad&#305;";
$langUserNo = "Kullan&#305;c&#305; No";
$langTaken = "sistemde kullan&#305;mdad&#305;r.L�tfen farkl&#305; bir tane se�in";
$langTutor = "Sorumlu";
$langUnreg = "Kay&#305;t sil";
$langGroupUserManagement = "Grup y�netimi";
$langUserInfo = "kullan&#305;c&#305; bilgisi";
$langUnregister = "Kay&#305;t &#304;ptal Et";
$langAddAUser = "Kullan&#305;c&#305; ekle";
?>