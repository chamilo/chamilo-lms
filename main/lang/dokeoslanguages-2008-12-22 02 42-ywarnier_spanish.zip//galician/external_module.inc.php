<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langLinkSite = "Ligaz�n a unha web";
$langSubTitle = "Engadir � men� principal da s�a p�xina principal unha ligaz�n a unha p�xina, no interior ou exterior da s�a web";
$langAddPage            = "Engadir p�xina";
$langSendPage           = "P�xina para enviar";
$langCouldNot           = "O arquivo non se pode enviar";
$langOkSentPage         = "Enviouse a p�xina.<p>Agora est� na<a href=\"../..//index.php\">P�xina inicial do curso</a>";
$langOkSentLink         = "Enviouse a ligaz�n.<p>Agora est� accesible desde <a href=\"../..//index.php\">P�xina inicial do curso</a>";
$langTooBig             = "Non seleccionaches o arquivo para enviar, ou � demasiado grande";
$langExplanation        = "A p�xina debe estar en formato HTML (e.x. \"paxina.htm\"). Enlazar�se � p�xina inicial. Se queres enviar documentos que non sexan HTML (PDF, Word, Power Point, V�deo, etc.) utiliza a <a href=../document/document.php>ferramenta Documentos</a>";
$langPgTitle            = "T�tulo da p�xina";
$langNoLinkURL          = "Introduza o enderezo da ligaz�n";
$langLinkTarget = "Destino da ligaz�n";
$langSameWindow = "Na mesma xanela";
$langNewWindow = "Nunha xanela nova";
$langAdded = "A ligaz�n foi engadida";
$langAddLink = "Engadir unha ligaz�n";
$langNoLinkName = "Introduza o nome da ligaz�n";
$langEditLink = "Modificar a ligaz�n da p�xina inicial do curso";
$langChangePress = "Cambiar e pulsar OK";
$langLinkChanged = "A ligaz�n da p�xina inicial do curso cambiou. Emprega o men� de arriba para volver a p�xina inicial. ";
$NoLinkName = "Ligaz�n sen nome";
$NoLinkURL = "Ligaz�n sen URL";
$LinkChanged = "Ligaz�n modificada";
$OkSentLink = "Envouse a ligaz�n";
?>