<?php /*
for more information: see languages.txt in the lang folder. 
*/
$TermAddNew = "Aggiungi una voce";
$TermName = "Voce";
$TermDefinition = "Definizione";
$TermDeleted = "Voce eliminata";
$TermUpdated = "Voce aggiornata";
$TermConfirmDelete = "Vuoi veramente eliminare la voce?";
$TermAddButton = "Aggiungi questa voce";
$TermUpdateButton = "Aggiorna la voce";
$TermEditAction = "Modifica la voce";
$TermDeleteAction = "Elimina la voce";
$OrderBy = "Ordina per";
$CreationDate = "Data di creazione";
$UpdateDate = "Aggiorna la data";
$PreSelectedOrder = "Ordina per selezione";
?>