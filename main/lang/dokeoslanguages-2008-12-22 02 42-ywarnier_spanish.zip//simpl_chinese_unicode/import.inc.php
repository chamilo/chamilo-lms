<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langPgTitle = "网页标题";
$langExplanation = "网页必须是 HTML 格式（比如：\"my_page.htm\"），它将会成为主页上的一个链接，如果需要发送非 HTML 格式（PDF、Word、PowerPoint、Video等等）文件，请使用<A href=\"../document/document.php\">课程讲义</A>";
$langTooBig = "没有选择任何文件发送，或者文件过大";
$langCouldNot = "文件发送失败";
$langNotAllowed = "禁用";
$langAddPageToSite = "为网站添加网页";
$langCouldNotSendPage = "文件不是 HTML 格式，发送失败，如果需要发送非 HTML 格式（PDF、Word、PowerPoint、Video等等）文件，请使用<A href=\"../document/document.php\">文件工具</A>";
$langSendPage = "要发送的网页";
$langPageTitleModified = "网页标题已更新";
$langPageAdded = "网页已添加";
$langAddPage = "添加网页";
?>