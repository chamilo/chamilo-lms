<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langScormBuilder = "建立路径 - 建立Scorm格式课程";
?>