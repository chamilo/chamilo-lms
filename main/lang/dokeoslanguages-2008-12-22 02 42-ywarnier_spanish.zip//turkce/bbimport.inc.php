<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langViewCourseMaterialImport  = "Ders materyalini al&#305;naca&#287;&#305; bi�imde g�ster";
$langViewExternalLinksImport  = "D&#305;&#351;ardan al&#305;nan linkleri al&#305;nd&#305;&#287;&#305; gibi g�ster";
$langViewForumImport  = "Forumu al&#305;naca&#287;&#305; bi�imde g�ster";
$langImportCourseMaterial  = "Ders malzemelerini i�e aktar (Yaz&#305; tahtas&#305; \"Ders Malzemesi\")";
$langImportExternalLinks  = "Ba&#287;lant&#305;lar&#305; al (Yaz&#305; tahtas&#305; arac&#305; \"Harici Ba&#287;lant&#305;lar\")";
$langImportForum  = "Forumlar&#305; i�e aktar (Yaz&#305;tahtas&#305; \"Tart&#305;&#351;ma Bordu\")";
$langToolInfo  = "Bu ara� Yaz&#305; Tahtas&#305; 5.5 derslerini almak i�indir.(Ders materyali, forum, harici ba&#287;lant&#305;lar)";
$langToolName = "KaraTahta Derslerini Al";
$langSelectCoursePackage = "Bir ders paketi se�iniz";
$langPackageAlreadySelected = "Zaten bir paket se�tiniz";
$langFirstSelectPackage = "Alma i&#351;leminden �nce bir paket se�ip a�mal&#305;s&#305;n&#305;z.";
$langCourseToMigrate = "Ta&#351;&#305;nacak Ders";
$langSelectPackage = "Bir paket se�";
$langOpenPackageForImporting = "Bu paketi i�e aktar&#305;m i�in a�";
$langInformation = "i�e aktar&#305;m i&#351;lemi hakk&#305;nda bilgi";
$langChooseImportOptions = "&#304;�e aktar&#305;m se�eneklerinizi se�iniz";
$langCheckWhatIsImported = "Alma i&#351;lemini ba&#351;latmadan �nce nelerin al&#305;naca&#287;&#305;n&#305; kontrol edebilirsiniz.";
$langStartImporting = "&#304;&#351;lemi Ba&#351;lat";
$langImport = "Dersleri Al";
?>