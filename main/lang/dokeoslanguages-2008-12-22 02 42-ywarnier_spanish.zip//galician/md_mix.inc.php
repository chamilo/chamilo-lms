<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langTool = "Metadatos";
$langClickKw = "Pulse nunha palabra chave da �rbore para seleccionar ou deselecciona-la";
$langKwHelp = "<br/> Pulse o bot�n \'+\' para abrir, o bot�n \'-\' para pechar, o bot�n  \'++\' para abri-los todos, o bot�n  \'--\' para pecha-los todos.<br/> <br/>Borrar todas as palabras chave pechando a �rbore e abr�ndola de novo co bot�n \'+\'.<br/> Alt-click \'+\' busca as palabras orixinais na �rbore. <br/> <br/> Alt-click \'+\' reselecciona as palabras seleccionadas previamente.<br/> <br/> Alt-click palabra chave nega a palabra chave.<br/> <br/>";
$langAdvanced = "Avanzado";
$langSearch = "Buscar";
$langSearchCrit = "�Use o espacio de abaixo para palabras descriptivas, unha palabra por li�a!";
$langNoKeywords = "Este curso non cont�n palabras chave";
$langKwCacheProblem = "O cach� de palabras chave non pode abrirse";
$langCourseKwds = "palabras chave do curso";
$langKwdsInMD = "palabras chave usadas nos Metadatos (MD)";
$langKwdRefs = "referencias da palabra chave";
$langNonCourseKwds = "Palabras chave non ligadas � curso";
$langKwdsUse = "Palabras chave do curso (negri�a = sen usar)";
$langTotalMDEs = "N�mero total de entradas MD:";
?>