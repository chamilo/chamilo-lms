<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langTool = "Metadata";
$langClickKw = "Pro zvolen� nebo zru�en� volby klikn&#283;te na kl�&#269;ov� slovo v stromu.";
$langKwHelp = "<br/> Klikn&#283;te na \'+\' tla&#269;�tko pro otev&#345;en�, \'-\' tla&#269;�tko pro zav&#345;en�, \'++\' tla&#269;�tko pro otev&#345;en� v�eho, \'--\' tla&#269;�tko pro zav&#345;en� v�eho.<br/> <br/> Pro odzna&#269;en� v�ech vybran�ch kl�&#269;ov�ch slov zav&#345;ete strom a op&#283;t jej otev&#345;te pomoc� \'+\' tla&#269;�tka.<br/> Alt-klik \'+\' pro op&#283;tovn� vybr�n� posledn&#283; vybran�ch kl�&#269;ov�ch slov.<br/> <br/> Alt-klik na kl�&#269;ov� slovo neguje toto slovo.<br/>";
$langAdvanced = "Pokro&#269;il�";
$langSearch = "Vyhledat";
$langSearchCrit = "Pou�ijte spodn� oblast pro popis slov, jedno slovo na &#345;�dek!";
$langNoKeywords = "Tento kurz nem� kl�&#269;ov� slov�";
$langKwCacheProblem = "Z�soba kl�&#269;ov�ch slov nem&#367;�e b�t otev&#345;ena";
$langCourseKwds = "kl�&#269;ov� slova kurzu";
$langKwdsInMD = "kl�&#269;ov� slova pou�ita v MD(metadata)";
$langKwdRefs = "reference dle kl�&#269;ov�ch slov";
$langNonCourseKwds = "Kl�&#269;ov� slov� nepat&#345;�c� kurzu";
$langKwdsUse = "Kl�&#269;ov� slov� (tu&#269;n� = nepou�it�)";
$langTotalMDEs = "Celkov� po&#269;et z�pis&#367; do MD:";
?>