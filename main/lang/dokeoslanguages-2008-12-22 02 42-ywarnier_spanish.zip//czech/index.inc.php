<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langInvalidId = "P&#345;ihl�en� selhalo. Zadejte pros�m platn� u�ivatelsk� jm�no a heslo.";
$langPass = "Heslo";
$langReg = "Registrace";
$langMenu  = "Menu";
$langOtherCourses = "Seznam kurz&#367;";
$langCategories  = "Kategorie";
$langBackToHomePage  = "P&#345;ehled kategori�";
$langCourseList  = "Kurzy";
$langHelptwo = "N�pov&#283;da";
$EussMenu = "menu";
$langMenuUser = "U�ivatel";
$langRefresh = "obnovit str�nku";
?>