<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langDownloadFile = "上传文件";
$langTooBig = "没有选择文件或文件太大。";
$langListDeleted = "整个列表已删除。";
$langDocModif = "论文标题已修改";
$langDocAdd = "作业已经上传。";
$langDocDel = "文件已经删除";
$langTitleWork = "文件标题";
$langAuthors = "作者";
$langDelList = "删除整个列表";
$langWorkDelete = "删除";
$langWorkModify = "修改";
$langWorkConfirmDelete = "你真的想要删除这个文件";
$langAllFiles = "应用于本课程所有作业";
$lang_default_upload = "作业可见性的默认设置";
$lang_new_visible = "作业对所有人都可见";
$lang_new_unvisible = "作业只对课程管理员可见";
$lang_doc_unvisible = "作业只对这门课程的教师可见, 因此对你是不可见的。";
$langDelLk = "删除链接";
$langMustBeRegisteredUser = "只有此课程的注册用户可以上传作业。";
$langListDel = "删除列表";
$langNameDir = "重命名目录";
$langFileExists = "文件已存在";
$langDirCr = "新建目录";
$langCurrentDir = "当前目录";
?>