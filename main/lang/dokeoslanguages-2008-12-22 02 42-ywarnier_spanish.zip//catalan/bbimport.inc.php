<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langViewCourseMaterialImport  = "Visualitzar el material del curs que ser� importat";
$langViewExternalLinksImport  = "Viasulaitzar els enlla�os externs que seran importats";
$langViewForumImport  = "Visualitzar el forum que ser� importat";
$langImportCourseMaterial  = "Importar material del curs (Blackboard modul \"Material del curs)";
$langImportExternalLinks  = "Importar enlla�os (Blackboard m�dul \"Enlla�os externs)";
$langImportForum  = "Importar f�rums (Blackboard m�dul \"F�rum de discussi�\")";
$langToolInfo  = "Aquesta eina importa cursos del Balckboard 5.5 (Material de cursos, foro de discussi�, i enlla�os externs)";
$langToolName = "Importar cursos de la pissarra";
$langSelectCoursePackage = "Seleccionat un curs empaquetat";
$langPackageAlreadySelected = "Ja heu seleccionat el curs en un paquet";
$langFirstSelectPackage = "Heu de seleccionar un paquet i obrir-lo abans de continuar amb la importaci�";
$langCourseToMigrate = "Curs a transferir";
$langSelectPackage = "Seleccionar un paquet";
$langOpenPackageForImporting = "Obrir aquest paquet per a importar";
$langInformation = "Informaci� sobre el poc�s d\'importaci�";
$langChooseImportOptions = "Escolliu les vostres opcions d\'importaci�";
$langCheckWhatIsImported = "Podeu verificar per a veure que ser� importat abans de comen�ar el proc�s d\'importaci�";
$langStartImporting = "Comen�ar la importaci�";
$langImport = "Importar";
?>