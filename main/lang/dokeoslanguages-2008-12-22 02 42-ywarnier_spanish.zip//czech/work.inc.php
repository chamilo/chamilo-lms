<?php /*
for more information: see languages.txt in the lang folder. 
*/
$Tools  = "N�stroje";
$langDownloadFile = "Ulo� soubor na server (upload)";
$langTooBig = "Nevybral jste soubor nebo je soubor p&#345;�li� velk�.";
$langListDeleted = "Cel� seznam byl smaz�n.";
$langDocModif = "n�zev dokumentu upraven";
$langDocAdd = "Soubor byl p&#345;idan� na seznam publikovan�ch.";
$langDocDel = "Soubor smaz�n";
$langTitleWork = "N�zev souboru";
$langAuthors = "Auto&#345;i";
$langDelList = "Smazat cel� seznam";
$langWorkDelete = "Vyma�";
$langWorkModify = "Upravit";
$langWorkConfirmDelete = "Skute&#269;n&#283; chcete smazat tento soubor";
$langAllFiles = "Akce na ve�ker�ch souborech";
$lang_default_upload = "V�choz� nastaven� viditelnosti nov&#283; zaslan�ch soubor&#367;";
$lang_new_visible = "Nov� dokumenty jsou viditeln� pro v�echny u�ivatele";
$lang_new_unvisible = "Nov� dokumenty jsou viditeln� pouze pro spr�vce kurzu";
$lang_doc_unvisible = "V� soubor je viditeln� pouze pro u&#269;itele kurzu a proto V�m nebude zobrazen.";
$langDelLk = "Vymazat odkaz";
$langMustBeRegisteredUser = "Jen registovan� u�ivatel� tohoto kurzu sm� publikovat dokumenty.";
$langListDel = "Vymazat seznam";
$langNameDir = "P&#345;emenuj slo�ku";
$langFileExists = "Soubor ji� existuje";
$langDirCr = "Vytvo&#345;it slo�ku";
$langCurrentDir = "aktu�ln� slo�ka";
$UploadADocument = "Ulo�it dokument na server ";
$EditToolOptions = "Mo�nosti n�stroje pro �pravu ";
$DocumentDeleted = "Dokument smaz�n";
$DirDelete = "Smazat adres�&#345;";
$ValidateChanges = "Potvrdit zm&#283;ny";
?>