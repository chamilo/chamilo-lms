<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langLineNumber = "行数";
$langLine = "行";
$langLines = "行";
$langLineOrLines = "行";
$langMoveUp = "上移";
$langMoveDown = "下移";
$langAddNewHeading = "添加新标题";
$langCourseAdministratorOnly = "仅教师";
$langDefineHeadings = "定义标题";
$langBackToUsersList = "返回列表";
$langTracking = "学习进度";
$langCourseManager = "教师";
$langModRight = "更改权限";
$langNoAdmin = "从现在开始<B>无权</B>查看本页";
$langAllAdmin = "从现在开始<b>有权</b>查看此页";
$langModRole = "改变角色";
$langRole = "角色";
$langIsNow = "是从现在开始的";
$langInC = "在这门课程中";
$langFilled = "不必填写所有选项";
$langUserNo = "用户序号";
$langTaken = "正在使用. 请选择另外一个";
$langTutor = "导师";
$langUnreg = "注销";
$langGroupUserManagement = "小组管理";
$langUserInfo = "用户信息";
$langUnregister = "注销";
$langAddAUser = "添加用户";
?>