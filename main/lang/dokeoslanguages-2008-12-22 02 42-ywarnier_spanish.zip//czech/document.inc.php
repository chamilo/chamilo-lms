<?php /*
for more information: see languages.txt in the lang folder. 
*/
$MoveTo = "P&#345;esunout do";
$langDownloadFile = "Ulo�it soubor na server";
$langNameDir = "N�zev nov� slo�ky";
$langSize = "Velikost";
$langRename = "P&#345;ejmenovat";
$langCopy = "Kop�rovat";
$langTo = "do";
$langNoSpace = "Ulo�en� na server se nezda&#345;ilo. P&#345;ekro&#269;ili jste maxim�ln� kv�tu, nebo tam nen� m�sto na disku.";
$langDownloadEnd = "Ulo�en� na server je dokon&#269;eno";
$langFileExists = "Operaci nen� mo�n� vykonat, proto�e soubor s takov�m jm�nem ji� existuje.";
$langNewDir = "N�zev nov� slo�ky";
$langImpossible = "Operace nen� mo�n�";
$langAddComment = "P&#345;idat/upravit koment�&#345; k";
$langDocCopied = "Dokument je zkop�rovan�";
$langDocDeleted = "Dokument je vymazan�";
$langElRen = "Element je p&#345;ejmenovan�";
$langDirCr = "Slo�ka vytvo&#345;en�";
$langDirMv = "Element je p&#345;esunut�";
$langComMod = "Koment�&#345; byl upraven";
?>