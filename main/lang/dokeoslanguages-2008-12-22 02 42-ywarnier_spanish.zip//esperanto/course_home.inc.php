<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langActivate = "Aktivigi ";
$langDeactivate = "Malaktivigi ";
$langInLnk  = "Tiuj &#265;i moduloj kaj ligiloj estas nun ne aktivaj ";
$langDelLk = "&#264;u vi volas forigi &#265;i-ligilon?";
$langEnter  = "Enigi";
$langCourseCreate  = "Krei retkurson ";
$langNameOfTheLink  = "Nomo de la ligilo ";
$lang_main_categories_list                  = "&#284;enerala kategorilisto ";
$langCourseAdminOnly = "Rezervita al kursmastrumantoj ";
$PlatformAdminOnly = "Rezervita al platforma mastrumanto ";
$langCombinedCourse = "Kombinita: ";
$ToolIsNowVisible = "La modulo nun videblas ";
$ToolIsNowHidden = "La modulo nun estas nevidebla ";
$EditLink = "&#348;an&#285;u ligilon ";
$Blog_management = "Bloga mastrumado";
$Forum = "Forumoj";
$Course_maintenance = "Kursmastrumado";
$TOOL_SURVEY = "Enketoj";
$GreyIcons = "Moduloj";
$Interaction = "Interago";
$Authoring = "Redakti";
$Administration = "Administrado";
?>