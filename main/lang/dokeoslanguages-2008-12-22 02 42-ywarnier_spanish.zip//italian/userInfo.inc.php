<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langLineNumber = "N. di righe";
$langLine = "riga";
$langLines = "righe";
$langLineOrLines = "righe";
$langMoveUp = "Sposta in su";
$langMoveDown = "Sposta in gi�";
$langAddNewHeading = "Aggiungi un\'intestazione";
$langCourseAdministratorOnly = "Riservato al gestore del corso";
$langDefineHeadings = "Definisci le intestazioni";
$langBackToUsersList = "Ritorna all\'elenco degli utenti";
$langTracking = "Tracciamento";
$langCourseManager = "Gestore del corso";
$langModRight = "cambia i diritti di";
$langNoAdmin = "da ora <b>non ha alcun diritto</b> su questa pagina";
$langAllAdmin = "da ora ha <b> tutti</b> i diritti su questa pagina";
$langModRole = "Cambia il ruolo di";
$langRole = "Ruolo";
$langIsNow = "� da ora";
$langInC = "in questo corso";
$langFilled = "Alcuni campi non sono stati completati";
$langUserNo = "Utente n.";
$langTaken = "gi� in uso. Scegline uno diverso";
$langTutor = "Tutor";
$langUnreg = "Cancella";
$langGroupUserManagement = "Gestione gruppi";
$langUserInfo = "informazioni sull\'utente";
$langUnregister = "Cancella l\'iscrizione";
$langAddAUser = "Aggiungi utenti";
$UsersUnsubscribed = "Gli utenti selezionati sono stati cancellati dal corso";
$ThisStudentIsSubscribeThroughASession = "Il corsista � iscritto al corso tramite una sessione. Non si possono modificare queste informazioni";
?>