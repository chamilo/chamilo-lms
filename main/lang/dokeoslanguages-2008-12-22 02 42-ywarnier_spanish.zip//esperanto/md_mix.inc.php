<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langTool = "Metadatumoj";
$langClickKw = "Musklaku &#349;losilvorton en la arbo por elekti a&#365; malelekti &#285;in.";
$langKwHelp = "<br/> Klaku la butonon \'+\' por malfermi, \'-\' por fermi, \'++\' por &#265;ion malfermi, \'--\' por &#265;ion fermi.<br/> <br/>Por malelekti &#265;iun elektitan &#349;losilvorton, fermu la arbon kaj remalfermi &#285;in per la butono \'+\'.<br/> Alt-klaku \'+\' por reelekti la anta&#365;e elektitajn &#349;losilvortojn.<br/> <br/> Alt-klaku &#349;losilvorton por nei &#285;in.<br/>";
$langAdvanced = "Altnivela";
$langSearch = "Ser&#265;i";
$langSearchCrit = "Uzu la suba aero por priskribemaj vortoj, po unu linie!";
$langNoKeywords = "Tiu &#265;i kurso ne havas &#349;losilvortojn.";
$langKwCacheProblem = "Ne eblas malfermi la provizejon de &#349;losilvortoj";
$langCourseKwds = "&#349;losilvortoj de la kurso";
$langKwdsInMD = "&#349;losilvortoj uzataj en MD";
$langKwdRefs = "&#349;losilvortaj referencoj";
$langNonCourseKwds = "Ne-kursaj &#349;losilvortoj";
$langKwdsUse = "Kursaj &#349;losilvortoj (grasaj = ne uzataj)";
$langTotalMDEs = "Nombro da MD-eroj:";
?>