<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langClarContent = "<br><p><b>Studento</b></p> <p>Por viziti kursojn alireblajn de el la Dokeos-startpa&#285;o, sufi&#265;as musklaki la kodon de la kurso en la kurslisto sen bezono de anta&#365;a registrado.</p><p>Por ekhavi aliron al kursoj ne alireblaj de el la universitata startpa&#285;o, ja necesas anta&#365;a registri&#285;o.<b>Registrado > plenigu viajn personajn datumojn > Ago: Registri&#285;i por kursoj > Elektu la kursojn kaj musklaku \'en ordo\'.</b></p><p>Retpo&#349;ta mesa&#285;o estos sendata, en kiu via uzula nomo kaj via pasvorto estas memorige sciigataj..</p> <hr noshade size=1> <p><b>Instruisto</b></p> <p><b>Krei kursejon</b></p> <p>Faru tiele: <b>Registrado > Plenigu &#265;iujn kampojn kaj elektu kiel agon \'krei kursojn\'  > Musklaku \'en ordo\' > Enigu la nomon de la kurso. Elektu &#265;u fakultato, &#265;u faka grupo. Enigu la referencojn de la kurso > musklaku sur \'en ordo\'</b>.  Vi tiam alvenas en via persona pa&#285;o en Dokeos. &#264;i tie vi trovas la liston de kursoj, en kiuj vi estas registrita. Musklaku sur la nomo de la kurso, kiun vi kreis. Vi alvenas en \'malplenan\' kursejon. Malplena tiusence, ke nur estas ekzemplaj elementoj, por ke vi ne tro ektimu pro la ekvido de malplenaj pa&#285;oj. &#264;e via registri&#285;o vi ricevis retmesa&#285;on, en kiu memorige estis menciitaj via uzulnomo kaj via pasvorto.</p> <p>Se estus problemo, kontakti&#285;u kun via Dokeos-mastrumanto. Vi anka&#365; povas publikigi mesa&#285;on en la subtena forumo de <a href=http://www.dokeos.com>http://www.dokeos.com</a>.</p>";
$test = "testo";
$WCAGImage = "Bildo";
$WCAGLabel = "Etikedo de bildo";
$WCAGLink = "Ligo";
$WCAGLinkLabel = "Titolo de ligo";
$errorNoLabel = "Mankas etiketo &#265;e la bildo";
$AllLanguages = "&#264;iuj lingvoj";
$WCAGEditor = "Redaktilo WCAG";
$WCAGGoMenu = "Iri al la menuo";
$WCAGGoContent = "Iri al la enhavo";
?>