<?php /*
for more information: see languages.txt in the lang folder. 
*/
$ResourceAdded = "Resource added. You can now go back to the path or add more resources.";
$LearningPath = "Learning Path";
$LevelUp = "level up";
$AddIt = "Add it";
$MainCategory = "main category";
$lang_delete_added_resources = "Delete added resources";
$AddToLinks = "Add to the course links";
$DontAdd = "do not add";
$lang_show_all_added_resources = "Show all added resources";
$ResourcesAdded = "Added new resources";
$BackTo = "Back to";
$ExternalResources = "External resources";
$CourseResources = "Course resources";
$ExternalLink = "External link";
$DropboxAdd = "Add the dropbox page to this chapter.";
$AddAssignmentPage = "Add the upload assignment page to this chapter.";
$Exercise = "Test";
$Link = "Link";
$AdValvas = "Ad Valvas";
$Document = "Document";
?>