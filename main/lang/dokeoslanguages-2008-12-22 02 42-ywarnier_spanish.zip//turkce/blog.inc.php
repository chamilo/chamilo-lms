<?php /*
for more information: see languages.txt in the lang folder. 
*/
$MyTasks = "Görevlerim";
$FavoriteBlogs = "Gözde günlüklerim";
$Subtitle = "Altbaşlık";
$ThisBlog = "Bu günlük";
$NewPost = "Yeni makale";
$TaskManager = "G�rev Y�netimi";
$Home = "Ana sayfa";
$NewComment = "Yeni bir yorum ekle";
$ReplyToThisComment = "Bu yoruma cevap yaz";
$langTask1Desc = "Görev 1 açıklaması";
$langTask2Desc = "Görev 2 açıklaması";
$langTask3Desc = "Görev 3 açıklaması";
$blog_management = "Günlük yönetimi";
$langWelcome = "Hoş geldiniz!";
?>