<?php /*
for more information: see languages.txt in the lang folder. 
*/
$lang_new_item = "yeni par�a eklendi";
$lang_title_notification = "Son ziyaretinizden beri";
$lang_update_agenda = "varolan etkinlik g�ncellendi";
$lang_new_agenda = "yeni etkinlik eklendi";
$lang_update_announcements = "varolan duyuru g�ncellendi";
$lang_new_announcements = "yeni duyuru eklendi";
$lang_new_document = "yeni belge(ler) eklendi";
$lang_new_exercise = "yeni al&#305;&#351;t&#305;rma aktif";
$lang_update_link = "varolan ba&#287;lant&#305; g�ncellendi";
$lang_new_link = "yeni ba&#287;lant&#305; eklendi";
$lang_new_forum_topic = "yeni ba&#351;l&#305;k eklendi";
$lang_new_groupforum_topic = "grup forumuna yeni ba&#351;l&#305;k eklendi";
$lang_new_dropbox_file = "yeni dosya al&#305;nd&#305;";
$lang_update_dropbox_file = "gelen kutusundaki dosyanız güncellendi";
?>